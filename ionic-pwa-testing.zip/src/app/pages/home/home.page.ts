import { Component, NgZone, OnInit } from '@angular/core';
import { Geolocation } from '@capacitor/geolocation';
export interface GeoL{
  altitude?: null;
  altitudeAccuracy?: null;
  heading?: null;
  latitude: any;
  longitude: any;
  speed?: null;
  timestamp?: any;
}
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  currentLoc:GeoL = null;
  currLocHis:GeoL[] = [];
  wait:any;
  constructor(private ngZone:NgZone) { }

  ngOnInit() {
    this.getCurrentLocation();
  }

  // get the current location
  async getCurrentLocation(){
   await Geolocation.getCurrentPosition().then(res=>{
      this.currentLoc = {latitude:res.coords.latitude,longitude:res.coords.longitude,timestamp:new Date(res.timestamp)}
      console.log("current location",this.currentLoc);
      this.currLocHis.unshift(this.currentLoc)
    });
  }
  async watchPos(){
  this.wait = await Geolocation.watchPosition({},(res,err)=>{
      console.log(res);
      this.ngZone.run(()=>{
        this.currentLoc = {latitude:res.coords.latitude,longitude:res.coords.longitude,timestamp:new Date(res.timestamp)}
        console.log("current location",this.currentLoc);
        this.currLocHis.unshift(this.currentLoc);
      })
    })
  }
  clearHistory(){
    this.currLocHis = [];
    Geolocation.clearWatch({id:this.wait});
  }
}
